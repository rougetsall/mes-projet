<?php
function addOrEven($date){
	if ($date % 2 == 0) {
		echo "odd";
		# code...
	}
	else{
		echo "even";
	}

}
addOrEven(3);
?>

