<?php
$nbline=0;
while ($nbline <= 10) {
	
echo $nbline."  sall rouget<br>";
$nbline++;
	# code...
}
for ($i=0; $i <10 ; $i++) { 
	# code...
	echo $i."  sall rouget<br>";
}




for ($i=0; $i <10 ; $i++) { 
	$t[$i]=$i+1;
	
}

for ($i=0; $i <10 ; $i++) { 
	echo $t[$i]."<br>";
	
}
?>