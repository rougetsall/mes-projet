
<html>
<head>
<title>Titre</title>
</head>
<body>
<?php
echo "Hello World !";
?>
</body>
</html>
