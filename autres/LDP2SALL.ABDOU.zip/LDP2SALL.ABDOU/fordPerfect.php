<?php
     $tab = array('Le Guide du voyageur galactique',
           'Le Dernier Restaurant avant la fin du monde',
            'La Vie lUnivers et le Reste',
           'Salut et encore merci pour le poison',
           'Globalment inoffensive');
    // for ($i=0; $i < 5; $i++) { 
	
	//echo $tab[$i]."<br>";
         //  }
           foreach ($tab as $vall) {

           	echo $vall."<br>";
           	# code...
           }

?>