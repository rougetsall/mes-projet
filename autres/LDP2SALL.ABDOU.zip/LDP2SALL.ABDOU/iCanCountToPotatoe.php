<?php
$i=0;

while ($i<11){
echo $i."<br>";
$i+=1;
}
?>